public class Som {
          public static char[] getTexto;
          public static String getSom(){
                    return "Som incorpado";
          }
        
          
}
