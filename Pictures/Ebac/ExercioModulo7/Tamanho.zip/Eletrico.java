public class Eletrico {
          public static char[] getTexto;
          /**
           * 
           * @return
           */
          public static String getEletrico(){
                    return "Eletrico";
          }
          /**
           * Tudo certinho
           */
}
