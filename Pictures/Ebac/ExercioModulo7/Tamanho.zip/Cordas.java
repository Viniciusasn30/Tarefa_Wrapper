public class Cordas {
         
          public static char[] getTexto;
          
          public static String getViolao() {
                    return "6 cordas";
          }
          
}
