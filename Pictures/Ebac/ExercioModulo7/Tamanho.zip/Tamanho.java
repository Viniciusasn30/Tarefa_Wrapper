public class Tamanho {
          public static char[] getTexto;

          public static String getTamanho(){
                return "1m e 10cm";
          }
          
}
