public class Violao{

          public static void main (String args[]){
                    System.out.println("Violao");
                    System.out.println (Cordas.getViolao());
                    System.out.println (Som.getSom());
                    System.out.println(Tamanho.getTamanho());
                    System.out.println(Eletrico.getEletrico());

          }
}
